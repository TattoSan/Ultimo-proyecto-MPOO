//
//  SecondViewController.swift
//  Auth
//
//  Created by MacBook on 11/26/18.
//  Copyright © 2018 ioslab. All rights reserved.
//

import UIKit
import Firebase

class SecondViewController: UIViewController {
    @IBOutlet weak var correoRegistrarTF: UITextField!
    
    @IBOutlet weak var contraseñaRegistrarTF: UITextField!
    
    @IBOutlet weak var contraseñaConfirmaTF: UITextField!
    
    @IBAction func registrarButton(_ sender: UIButton) {
        Auth.auth().createUser(withEmail: correoRegistrarTF.text!, password: contraseñaRegistrarTF.text!, completion: nil)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
